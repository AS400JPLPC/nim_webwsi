cd /home/soleil/A_LITE/NimWeb/js/libs/

./Jsmin <validator.js> validator.min.js "JP laroche 2016/08/17"
./Jsmin <validatorfunc.js> validatorfunc.min.js "JP laroche 2016/08/17"
./Jsmin <ecr00.js> ecr00.min.js "JP laroche 2016/08/17"

exit 0
